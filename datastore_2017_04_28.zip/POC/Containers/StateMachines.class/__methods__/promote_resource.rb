#
# Description: <Method description here>
#

require 'kubeclient'

def remove_image_change_trigger(triggers)
  triggers.each { |trigger|
    if trigger[:type] == "ImageChange"
      triggers.delete(trigger)
    end
    }
  triggers
end

def get_route_name(project)
  ems_id = project.ext_management_system.id
  routes = $evm.vmdb(:container_route).where(:name => 'docker-registry', :ems_id => ems_id)
  route_name = routes[0].host_name
  route_name
end


def update_container_image_repo(containers, project_name, route_name)
	containers.each { |container|  
      image_name = []
      if match = container[:image].match(/172\.30\.\d{1,3}\.\d{1,3}:5000\/\S*\/(\S*)@/i)
        image_name = match.captures
      end
      container[:image].gsub!(/172\.30\.\d{1,3}\.\d{1,3}:5000\/\S*\//, route_name + '/' + project_name + '/')
      $evm.log("info","===> Container image repo is now #{container[:image]}")
      }
  containers
end

kind = $evm.inputs['kind']
key = 'dialog_option_0_' + kind.underscore.pluralize
$evm.log("info","===== BEGIN PROMOTING #{key} =====")

dialog_options = $evm.root["service_template_provision_task"].dialog_options
source_project_id = dialog_options['dialog_option_0_source_project']
source_project = $evm.vmdb('container_project').where('id = ?', source_project_id)
target_cluster_name = dialog_options['dialog_option_0_target_cluster'].gsub('-test', '')
target_ems = $evm.vmdb(:ext_management_system).find_by_name(target_cluster_name)
target_project_name = source_project[0].name
if dialog_options['dialog_option_0_target_cluster'].end_with? '-test'
  target_project_name = target_project_name + '-test'
end
  
target_project = $evm.vmdb('container_project').where('name = ? AND ems_id = ? AND deleted_on IS ?', target_project_name, target_ems.id, nil)

selected_resources = dialog_options['Array::'+key]
if selected_resources.nil?
  selected_resources = dialog_options[key]
end

unless selected_resources.kind_of?(Array)
  if selected_resources.include? ","
    selected_resources = selected_resources.split(",")
  else
    selected_resources = [selected_resources]
  end
end

selected_resources.each do |selected_resource|
  resource = source_project[0].get_resource_by_name(selected_resource, kind)
  
  resource[:kind] = kind.camelize
  resource[:metadata][:namespace] = target_project_name
  resource[:apiVersion] = 'v1'
  resource[:metadata].delete(:selfLink)
  resource[:metadata].delete(:uid)
  resource[:metadata].delete(:resourceVersion)
  resource[:metadata].delete(:creationTimestamp)
  resource[:metadata].delete(:generation)
  resource.delete(:status)
  resource[:spec].delete(:clusterIP)
  
  if kind.eql?'DeploymentConfig'
    route_name = get_route_name(source_project[0])
    resource[:spec][:triggers] = remove_image_change_trigger(resource[:spec][:triggers])
    resource[:spec][:template][:spec][:containers] = update_container_image_repo(resource[:spec][:template][:spec][:containers], target_project_name, route_name)
  elsif kind.eql?'Routes'
    route_destination_hostname = dialog_options['dialog_option_0_route_destination_hostname']
    if route_destination_hostname == ''
      resource[:spec].delete(:host)
    else
      resource[:spec][:host] = route_destination_hostname
    end
  end
  
  if target_project[0].get_resource_by_name(resource[:metadata][:name], kind).nil?
    target_project[0].create_resource(resource)
  else
    target_project[0].patch_resource(resource)
  end
end


$evm.log("info","===== END PROMOTING #{key} =====")


