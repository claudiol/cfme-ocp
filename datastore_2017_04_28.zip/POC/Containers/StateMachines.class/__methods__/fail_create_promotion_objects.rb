#
# Description: <Method description here>
#
$evm.root["miq_request"].deny("admin", "AUTO-DENIED - Objects inteded for promotion couldn't be created.")
exit MIQ_ERROR
