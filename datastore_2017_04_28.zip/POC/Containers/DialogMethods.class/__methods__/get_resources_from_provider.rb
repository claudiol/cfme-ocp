#
# Description: <Method description here>
#
require 'kubeclient'
kind = $evm.inputs['kind']
$evm.log("info","===== BEGIN GETTING #{kind} FROM PROVIDER =====")

dialog_field = $evm.object

project_id = $evm.root['dialog_option_0_source_project']
$evm.log("info","===> The project ID is #{project_id}")
project = $evm.vmdb('container_project').find_by_id(project_id)
project_name = project.name


resources = project.get_resources(kind)

hash = {}
resources.each { |resource| 
  
  resource_name = resource[:metadata][:name]
  hash[resource_name] = resource_name
  
  }

# sort_by: value / description / none
dialog_field["sort_by"] = "value"

# sort_order: ascending / descending
dialog_field["sort_order"] = "ascending"

# data_type: string / integer
dialog_field["data_type"] = "string"

# required: true / false
dialog_field["required"] = "true"

dialog_field["values"] = hash

$evm.log("info","===== END GETTING #{kind} FROM PROVIDER =====")
