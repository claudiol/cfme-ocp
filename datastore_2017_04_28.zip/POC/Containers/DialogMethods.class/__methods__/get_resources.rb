#
# Description: <Method description here>
#
kind = $evm.inputs['kind']
$evm.log("info","===== BEGIN GETTING #{kind} =====")

dialog_field = $evm.object

project_id = $evm.root['dialog_option_0_source_project']
$evm.log("info","===> The project ID is #{project_id}")
project = $evm.vmdb('container_project').find_by_id(project_id)

resources = $evm.vmdb(kind).where('container_project_id = ?', project_id)

hash = {}
resources.each { |resource| 
  $evm.log("info","Resource => #{resource.inspect}")
  resource_name = resource[:name]
  hash[resource_name] = resource_name
  
  }

# sort_by: value / description / none
dialog_field["sort_by"] = "value"

# sort_order: ascending / descending
dialog_field["sort_order"] = "ascending"

# data_type: string / integer
dialog_field["data_type"] = "string"

# required: true / false
dialog_field["required"] = "true"

dialog_field["values"] = hash

$evm.log("info","===== END GETTING #{kind} =====")
