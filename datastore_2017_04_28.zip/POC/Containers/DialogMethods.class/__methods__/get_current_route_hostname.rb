#
# Description: <Method description here>
#
$evm.log("info","===== BEGIN GETTING CURRENT ROUTE HOSTNAME =====")

dialog_field = $evm.object

project_id = $evm.root['dialog_option_0_source_project']
route_name = $evm.root['dialog_option_0_routes']

$evm.log("info","===> The project ID is #{project_id}")

routes = $evm.vmdb('container_route').where('name = ? AND container_project_id = ?', route_name, project_id)

dialog_field["read_only"] = "true"
dialog_field["value"] = routes[0].host_name
$evm.log("info","===== END GETTING CURRENT ROUTE HOSTNAME =====")
