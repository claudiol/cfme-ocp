#
# Description: This will tag project roles.  Container projects must be tagged with "cfme_managed/true"
#
require 'kubeclient'
require 'json'

$evm.log("info","===== Begin Tagging Project Roles =====")

def create_tags_if_not_exist(role, user)
  unless $evm.execute('category_exists?', 'ocp_role_' + role)
    $evm.execute('category_create',
                        :name => 'ocp_role_' + role,
                        :single_value => true,
                        :perf_by_tag => false,
                        :description => "OCP Role " + role)
  end

  unless $evm.execute('tag_exists?', 'ocp_role_' + role, 'true')
    $evm.execute('tag_create', 
                        'ocp_role_' + role,
                        :name => user,
                        :description => user)
  end
end

def tag_project_user_role(project, roleref, role)
  $evm.log("info","Project #{role}s are #{roleref[:userNames]}")
  users = roleref[:userNames]
  users.each { |user| create_tags_if_not_exist(role, user)
    project.tag_assign('ocp_role_' + role + '/' + user)
    }
end


roles = ['admin','edit','view']

dialog_options = $evm.root["service_template_provision_task"].dialog_options
project_name = ""
project = nil
target_cluster_name = dialog_options['dialog_option_0_target_cluster'].gsub('-test', '')
target_cluster = $evm.vmdb('ext_management_system').find_by_name(target_cluster_name)
target_cluster_id = target_cluster.id

unless dialog_options['dialog_option_0_service_name'].nil?
  project_name = dialog_options['dialog_option_0_service_name']
else
  project_id = dialog_options['dialog_option_0_source_project']
  project = $evm.vmdb(:container_project).find_by_id(project_id)
  project_name = project.name
  if dialog_options['dialog_option_0_target_cluster'].end_with? '-test'
    project_name = project_name + '-test'
  end
end
project = $evm.vmdb('container_project').where("name = ? AND ems_id = ? AND deleted_on IS ?", project_name, target_cluster_id, nil)

bindings = project[0].get_resources("RoleBindings")
$evm.log("info","Project Role Bindings #{bindings}")
roles.each do |role| 
  bindings.each do |roleref|
    if roleref[:metadata][:name] == role
      tag_project_user_role(project[0], roleref, role)
    end
  end
end


$evm.log("info","===== End Tagging Project Roles =====")
