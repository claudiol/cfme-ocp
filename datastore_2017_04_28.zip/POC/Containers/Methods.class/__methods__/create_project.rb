# Description: This method creates a container project
require 'kubeclient'

container_project_name = ""
container_project_display_name = ""
container_project_description = ""
cluster_name = ""
testing = false

dialog_options = $evm.root["service_template_provision_task"].dialog_options
cluster_name = dialog_options['dialog_option_0_target_cluster']

if cluster_name.end_with? '-test'
  testing = true
  cluster_name.gsub!('-test', '')
end

$evm.log("info", "========= CREATING PROJECT IN CLUSTER #{cluster_name} =========")

ems = $evm.vmdb(:ext_management_system).find_by_name(cluster_name)
project = Kubeclient::Resource.new
project.metadata = {}
unless dialog_options['dialog_option_0_service_name'].nil?
  project.metadata.name = dialog_options['dialog_option_0_service_name']
  project.displayName = dialog_options['dialog_option_0_display_name']
  project.description = dialog_options['dialog_option_0_project_description']
  ems.create_project(project.to_h)
else
  container_project_id = dialog_options['dialog_option_0_source_project']
  container_project = $evm.vmdb(:container_project).find_by_id(container_project_id)
  project.metadata.name = container_project.name
  project.displayName = container_project.display_name
  if testing
    project.metadata.name = project.metadata.name + '-test'
  end
  
  unless ems.project_exists_in_provider?(project.metadata.name)
    ems.create_project(project.to_h)
  end
  
end

  

$evm.log("info", "======= END CREATING PROJECT IN CLUSTER #{cluster_name} =======")

$evm.root["service_template_provision_task"].execute
