# Description: This method adds a user to the project in the role of admin

require 'kubeclient'

task = $evm.root["service_template_provision_task"]
dialog_options = task.dialog_options
project_name = dialog_options['dialog_option_0_service_name']

$evm.log("info", "========= ADDING USER TO PROJECT #{project_name} =========")

#Get the requester from the provision object
user = task.miq_request.requester
raise "User not specified" if user.nil?

$evm.log("info"," Detected requester is #{user}")

#Get the user's current group
group = user.current_group
user_role = group.tags("ocp_project_role")[0]

userid = user.userid

userid = user.userid
if userid.start_with?("uid")
  userid = user.get_ldap_attribute("uid")
end

ems =$evm.vmdb(:ext_management_system).find_by_name(dialog_options['dialog_option_0_target_cluster'])
project = $evm.vmdb('container_project').where('name = ? AND ems_id = ? AND deleted_on IS ?',project_name, ems.id, nil) 

$evm.log("info","--- The user role being added to user #{userid} is #{user_role} ---")
project[0].add_role_to_user(userid, user_role)

$evm.log("info", "====== END USER #{userid} TO PROJECT #{project_name} ======")
