#
# Description: <Method description here>
#
require 'kubeclient'
require 'base64'

$evm.log("info","===== BEGIN TRANSFER IMAGE PULLER SECRETS =====")

def get_route_name(project)
  ems_id = project.ext_management_system.id
  routes = $evm.vmdb(:container_route).where(:name => 'docker-registry', :ems_id => ems_id)
  route_name = routes[0].host_name
  route_name
end

def extract_secret(secrets, secret_type)
  secrets.each { |secret|
    if secret[:metadata][:name].start_with? secret_type
      return secret
    end
    }
end

def cleanup_secret_data(registry_host, secret)
  datas_value = secret[:data][:".dockercfg"]
  datas_value_dec = Base64.decode64(datas_value)
  $evm.log('info',"==> Datas Value Decoded Before #{datas_value_dec}")
  datas_value_dec.gsub!(/172\.30\.\d{1,3}\.\d{1,3}:5000/, registry_host)
  datas_value_dec.gsub!(/,\"docker-registry.default.svc:5000\S*\"}/, '')
  $evm.log('info',"==> Datas Value Decoded After #{datas_value_dec}")
  
  Base64.encode64(datas_value_dec)
end

def create_secret(destination_project, destination_project_name, source_cluster_pretty_name, secret_type, data)
  
  secret_name = secret_type + source_cluster_pretty_name
  
  secret = Kubeclient::Resource.new
  secret.kind = 'Secret'
  secret.apiVersion = 'v1'
  secret.metadata = {}
  secret.metadata.name = secret_name
  secret.metadata.namespace = destination_project_name
  secret.data = {}
  secret.data[:".dockercfg"] = data
  secret.type = "kubernetes.io/dockercfg"

  $evm.log('info',"==> Attempting create secret #{secret.to_h}")
  
  if destination_project.get_resource_by_name(secret_name, 'Secret').nil?
    destination_project.create_resource(secret.to_h)
  else
    destination_project.patch_resource(secret.to_h)
  end
  
end

def assign_secret(destination_project, destination_project_name, sa_type, secret_name)
  sas = destination_project.get_resources('ServiceAccount')
  
  sas.each do |sa|
    
    if sa[:metadata][:name].eql? sa_type
      sa_reference = Kubeclient::Resource.new
      sa_reference.name = secret_name
      sa[:kind] = 'ServiceAccount'
      sa[:apiVersion] = 'v1'
      #Oddly there is sometimes a race condition where the association between an
      #image pull secret and SA lingers, even after a project is destroyed.  This
      #should clean it up.
      #image_pull_secrets = sa[:imagePullSecrets].reject {|ips| ips == sa_reference}
      #image_pull_secrets.push(sa_reference)
      #sa[:imagePullSecrets] = image_pull_secrets
     
      destination_project.patch_resource(sa)
      
    end
  end
  
end

task = $evm.root["service_template_provision_task"]
dialog_options = task.dialog_options

dialog_options = $evm.root["service_template_provision_task"].dialog_options
target_cluster_name = dialog_options['dialog_option_0_target_cluster']
target_ems = $evm.vmdb(:ext_management_system).find_by_name(target_cluster_name.gsub('-test',''))

project_id = dialog_options['dialog_option_0_source_project']
project = $evm.vmdb(:container_project).find_by_id(project_id)
project_name = project.name

target_project_name = project_name
if target_cluster_name.end_with? '-test'
  target_project_name = target_project_name + '-test'
end

target_project = $evm.vmdb('container_project').where('name = ? AND ems_id = ? and deleted_on IS ?',target_project_name, target_ems.id, nil)

source_ems = project.ext_management_system
source_cluster_pretty_name = source_ems.name.downcase.gsub(/[^a-z0-9]/i, '')

route_name = get_route_name(project)

secrets = project.get_resources('Secrets')

default_dockercfg_secret = extract_secret(secrets, "default-dockercfg-")
default_dockercfg_secret_data = cleanup_secret_data(route_name, default_dockercfg_secret)
create_secret(target_project[0], target_project_name, source_cluster_pretty_name, "default-dockercfg-", default_dockercfg_secret_data)
assign_secret(target_project[0], target_project_name, "default", "default-dockercfg-"+source_cluster_pretty_name)

deployer_dockercfg_secret = extract_secret(secrets, "deployer-dockercfg-")
deployer_dockercfg_secret_data = cleanup_secret_data(route_name, deployer_dockercfg_secret)
create_secret(target_project[0], target_project_name, source_cluster_pretty_name, "deployer-dockercfg-", deployer_dockercfg_secret_data)
assign_secret(target_project[0], target_project_name, "deployer", "deployer-dockercfg-"+source_cluster_pretty_name)

$evm.log("info","===== END TRANSFER IMAGE PULLER SECRETS =====")
