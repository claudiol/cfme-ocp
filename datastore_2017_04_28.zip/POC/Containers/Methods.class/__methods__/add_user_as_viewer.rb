# Description: This method adds a user to the project in the role of admin

require 'kubeclient'

task = $evm.root["service_template_provision_task"]
dialog_options = task.dialog_options

unless dialog_options['dialog_option_0_service_name'].nil?
	project_name = dialog_options['dialog_option_0_service_name']
else
    project_id = dialog_options['dialog_option_0_source_project']
	project = $evm.vmdb(:container_project).find_by_id(project_id)
    project_name = project.name
    if dialog_options['dialog_option_0_target_cluster'].end_with? '-test'
      project_name = project_name + '-test'
    end
end

$evm.log("info", "========= ADDING USER TO PROJECT #{project_name} =========")

#Get the requester from the provision object
user = task.miq_request.requester
raise "User not specified" if user.nil?

$evm.log("info"," Detected requester is #{user}")

#Get the user's current group
group = user.current_group
user_role = "view"

userid = user.userid

userid = user.userid
if userid.start_with?("uid")
  userid = user.get_ldap_attribute("uid")
end

ems = $evm.vmdb(:ext_management_system).find_by_name(dialog_options['dialog_option_0_target_cluster'].gsub('-test', ''))
project = $evm.vmdb('container_project').where('name = ? AND ems_id = ? AND deleted_on IS ?',project_name, ems.id, nil) 

$evm.log("info","--- The user role being added to user #{userid} is #{user_role} ---")
project[0].add_role_to_user(userid, user_role)

$evm.log("info", "====== END USER #{userid} TO PROJECT #{project_name} ======")
