#
# Description: Adds a user to the cluster.
#
require 'kubeclient'
$evm.log("info","===== BEGIN ADDING USER TO CLUSTER =====")

project_name = ""
project_display_name = ""
project_description = ""
cluster_name = ""
project = nil
ems = nil

task = $evm.root["service_template_provision_task"]
dialog_options = task.dialog_options

unless dialog_options['dialog_option_0_service_name'].nil?
  project_name = dialog_options['dialog_option_0_service_name']
  cluster_name = dialog_options['dialog_option_0_target_cluster']
  target_cluster = $evm.vmdb(:ext_management_system).find_by_name(cluster_name)
  cluster_id = target_cluster.id
  project = $evm.vmdb(:container_project).where("name = ? AND ems_id = ? AND deleted_on IS ?", project_name, cluster_id, nil)
else
  project_id = dialog_options['dialog_option_0_source_project']
  project = $evm.vmdb(:container_project).find_by_id(project_id)
  $evm.log("info", "==> Found project #{project.inspect}")
end

begin
  ems = project.ext_management_system
rescue NoMethodError
  ems = project[0].ext_management_system
end


#Get the requester from the provision object
user = task.miq_request.requester
raise "User not specified" if user.nil?

userid = user.userid
if userid.start_with?("uid")
  userid = user.get_ldap_attribute("uid")
end

$evm.log("info","==> Detected requester is #{userid}")

unless ems.user_exists_in_provider?(userid)
	ems.add_user_in_provider(userid) 
end

$evm.log("info","===== END ADDING USER TO CLUSTER =====")
