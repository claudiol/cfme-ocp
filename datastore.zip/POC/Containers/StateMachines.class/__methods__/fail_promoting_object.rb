#
# Description: <Method description here>
#
$evm.log("error","Failure promoting object.")
$evm.root['ae_result'] = 'error'
exit MIQ_ERROR
