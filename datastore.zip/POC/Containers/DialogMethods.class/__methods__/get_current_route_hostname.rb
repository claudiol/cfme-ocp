#
# Description: <Method description here>
#
require 'kubeclient'
$evm.log("info","===== BEGIN GETTING CURRENT ROUTE HOSTNAME =====")

dialog_field = $evm.object
user = $evm.root['user']

project_id = $evm.root['dialog_option_0_source_project']
route_name = $evm.root['dialog_option_0_route_name']

$evm.log("info","===> The project ID is #{project_id}")
project = $evm.vmdb('container_project').find_by_id(project_id)
project_name = project.name

client = project.ext_management_system.connect
unless client.discovered
  client.discover
end

routes = client.get_routes(namespace: project_name)
$evm.log("info", "Retrieved #{routes.length} routes for project #{project_name}")

host_name = ''
routes.each { |route| 
  
  if route_name.eql? route.metadata.name
    host_name = route.spec.host
     $evm.log("info","Matched route #{route_name} with hostname #{host_name}")
  end
  
  }
dialog_field["read_only"] = "true"
dialog_field["value"] = host_name
$evm.log("info","===== END GETTING CURRENT ROUTE HOSTNAME =====")
