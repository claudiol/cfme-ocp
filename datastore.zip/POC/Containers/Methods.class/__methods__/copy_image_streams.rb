#
# Description: copy image streams from one cluster to another
#
$evm.log("info","=== Copy Image Streams ===")
