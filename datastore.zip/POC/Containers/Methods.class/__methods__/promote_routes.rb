#
# Description: <Method description here>
#
require 'kubeclient'
require 'rest-client'

def update_route(route, target_route_name)
  
  route
end

$evm.log("info","===== BEGIN PROMOTING ROUTE =====")
dialog_options = $evm.root["service_template_provision_task"].dialog_options
target_cluster_name = dialog_options['dialog_option_0_target_cluster']
target_route_name = dialog_options['dialog_option_0_route_destination_hostname']
route_name = dialog_options['dialog_option_0_route_name']

source_project_id = dialog_options['dialog_option_0_source_project']
source_project = $evm.vmdb(:container_project).find_by_id(source_project_id)
project_name = source_project.name
source_cluster_name = source_project.ext_management_system.name

source_ems = $evm.vmdb(:ext_management_system).find_by_name(source_cluster_name)

client = source_ems.connect
unless client.discovered
  client.discover
end

routes = client.get_routes(namespace: project_name)

routes.each { |route| 
  
  $evm.log("info","Comparing desired route #{route_name} against #{route.metadata.name}")
  if route_name.eql? route.metadata.name
    $evm.log("info","=== MATCHED desired route #{route_name} against #{route.metadata.name}")
    route_hash = route.to_h
    route_hash[:metadata].delete(:selfLink)
    route_hash[:metadata].delete(:uid)
    route_hash[:metadata].delete(:resourceVersion)
    route_hash[:metadata].delete(:creationTimestamp)
    route_hash[:metadata].delete(:generation)
    route_hash[:metadata].delete(:annotations)
    route_hash.delete(:status)
    unless target_route_name.length == 0     
      route_hash[:spec][:host] = target_route_name
      $evm.log("info","=== Set target route to #{route_hash[:spec][:host]}")
    else
      $evm.log("info","=== Target route is nil.  Deleting host.}")
      route_hash[:spec].delete(:host)
    end
    $evm.log("info","====> ROUTE NOW #{route_hash}")
    
    target_ems = $evm.vmdb(:ext_management_system).find_by_name(target_cluster_name)
    client = target_ems.connect
    unless client.discovered
      client.discover
    end
 
    begin
    	client.create_route(route_hash)
    rescue KubeException => e
      if e.message.include? "already exists"
        $evm.log("info","====> ROUTE ALREADY EXISTS DELETING AND RECREATEING")
        client.delete_route(route_name, project_name)
        client.create_route(route_hash)
      else
        raise e
      end
    end
    
  end
  
  }

$evm.log("info","===== END PROMOTING ROUTE =====")

