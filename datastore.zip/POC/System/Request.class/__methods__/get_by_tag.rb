#
# Description: <Method description here>
#
$evm.log("info","========== GOT HERE ==========")

#tag = "/managed/environment/development"
managers = $evm.vmdb('container_manager').where(:name => 'Cluster A')

$evm.log("info","========== #{managers.inspect} ==========")
