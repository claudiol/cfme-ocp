#
# Description: This method is used to email the requester that the Service request was not auto-approved
#
require 'kubeclient'

def parse_configs(configs)
  unless configs.kind_of?(Array)
    if configs.include? ","
      configs = configs.split(",")
    else
      configs = [configs]
    end
  end
  configs
end

def get_container_images(config_name_array, project_name, source_ems)
  client = source_ems.connect
  unless client.discovered
    client.discover
  end
  
  images = {}
  dcs = client.get_deployment_configs(:namespace => project_name)
  config_name_array.each { |config|
    dcs.each { |dc|
      
      if dc.metadata.name.eql? config
		dc_hash = dc.to_h
        containers = dc_hash[:spec][:template][:spec][:containers]
        containers.each { |container|
          $evm.log("info"," ==> Image -- #{container[:image]}")
          name, digest = container[:image].split('@')
          images[digest] = name
          }
      end
      }
    }
  images
end

def send_mail(to, from, subject, body)
  $evm.log(:info, "Sending email to #{to} from #{from} subject: #{subject}")
  $evm.execute(:send_email, to, from, subject, body)
end

def requester
  @miq_request.requester
end

def signature
  $evm.object['signature']
end

def reason
  @miq_request.reason
end

def approver_href(appliance)
  body = "<a href='https://#{appliance}/miq_request/show/#{@miq_request.id}'"
  body += ">https://#{appliance}/miq_request/show/#{@miq_request.id}</a>"
  body
end

def approver_text(appliance, requester_email, images)
  body = "Approver, "
  body += "<br>An OCP Project Promotion Request received from #{requester_email} is pending."
  body += "<br>The promotion request references the following images:"
  body += "<table>"
  body += "<tr>"
  body += "<th>Image Name</th>"
  body += "<th>Digest</th>"
  body += "<th>Operating System</th>"
  body += "<th>OpenSCAP Result</th>"
  body += "</tr>"
  images.each { |digest, name|
    registry, repo, image_name = name.split('/')
    name = repo + '/' + image_name
    image = $evm.vmdb('container_image').where("name = ? AND digest = ?", name, digest)
    $evm.log("info","===> Image #{name} Insepction #{image}")
    body += "<tr>"
    body += "<td>#{name}</td>"
	body += "<td>#{digest}</td>"
    body += "<td>#{image[0].operating_system}</td>"
    #body += "<td>#{image[0].openscap_result}</td>"
    body += "</tr>"
    }
  body += "</table>"
  body += "<br><br>For more information you can go to: "
  body += approver_href(appliance)
  body += "<br><br> Thank you,"
  body += "<br> #{signature}"
  body
end

def requester_email_address
  owner_email = @miq_request.options.fetch(:owner_email, nil)
  email = requester.email || owner_email || $evm.object['to_email_address']
  $evm.log(:info, "To email: #{email}")
  email
end

def email_approver(appliance, images)
  $evm.log(:info, "Approver email logic starting")
  requester_email = requester_email_address
  to = $evm.object['to_email_address']
  from = $evm.object['from_email_address']
  subject = "Request ID #{@miq_request.id} - OCP Service request is pending"

  send_mail(to, from, subject, approver_text(appliance, requester_email, images))
end

def requester_href(appliance)
  body = "<a href='https://#{appliance}/miq_request/show/#{@miq_request.id}'>"
  body += "https://#{appliance}/miq_request/show/#{@miq_request.id}</a>"
  body
end

def requester_text(appliance)
  body = "Hello, "
  body += "<br><br>Please review your Request and wait for approval from an OCP Administrator."
  body += "<br><br>To view this Request go to: "
  body += requester_href(appliance)
  body += "<br><br> Thank you,"
  body += "<br> #{signature}"
  body
end

def email_requester(appliance)
  $evm.log(:info, "Requester email logic starting")
  to = requester_email_address
  from = $evm.object['from_email_address']
  subject = "Request ID #{@miq_request.id} - Your Service OCP Request is Pending"

  send_mail(to, from, subject, requester_text(appliance))
end

@miq_request = $evm.root['miq_request']
if @miq_request.nil?
  @miq_request = $evm.root['service_template_provision_request']
end

dialog_options = @miq_request.options[:dialog]
project_id = dialog_options['dialog_option_0_source_project']
source_project = $evm.vmdb('container_project').find_by_id(project_id)
source_ems = source_project.ext_management_system

deployment_configs = parse_configs(dialog_options['Array::dialog_option_0_deployment_configs'])

images = get_container_images(deployment_configs, source_project.name, source_ems)

$evm.log(:info, "miq_request id: #{@miq_request.id} approval_state: #{@miq_request.approval_state}")
$evm.log(:info, "options: #{@miq_request.options.inspect}")

service_template = $evm.vmdb(@miq_request.source_type, @miq_request.source_id)
$evm.log(:info, "service_template id: #{service_template.id} service_type: #{service_template.service_type}")
$evm.log(:info, "description: #{service_template.description} services: #{service_template.service_resources.count}")

appliance = $evm.root['miq_server'].hostname

email_requester(appliance)
email_approver(appliance, images)
